# flake8: noqa

from .predict import predict_label, predict_negative_instances
