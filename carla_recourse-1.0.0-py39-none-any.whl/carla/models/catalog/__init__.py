# flake8: noqa

from .catalog import MLModelCatalog
