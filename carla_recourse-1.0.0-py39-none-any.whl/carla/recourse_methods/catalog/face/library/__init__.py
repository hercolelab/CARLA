# flake8: noqa

from .face_method import graph_search
